package com.omabolaji.Drone.dto;

public enum ModelType {
    Lightweight, Middleweight, Cruiserweight, Heavyweight;
}
